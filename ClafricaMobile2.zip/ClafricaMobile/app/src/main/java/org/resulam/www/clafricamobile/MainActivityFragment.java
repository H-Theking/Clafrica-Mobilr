//package org.resulam.www.clafricamobile;
//
//import android.os.Bundle;
//import android.os.Parcelable;
//import android.support.v4.app.Fragment;
//import android.support.v4.app.FragmentActivity;
//import android.support.v4.app.FragmentStatePagerAdapter;
//import android.util.Log;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//
//import java.util.List;
//
///**
// * A placeholder fragment containing a simple view.
// */
//public class MainActivityFragment extends FragmentActivity {
//
//    public MainActivityFragment() {
//    }
//
//    @Override
//    public void onCreateView(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//
//        pager = findViewById(R.id.pager);
//
//
//        FragmentStatePagerAdapter adapter = new FragmentStatePagerAdapter(getSupportFragmentManager()) {
//            @Override
//            public Fragment getItem(int position) {
//
//                List<Fragment> f = getSupportFragmentManager().getFragments();
//
//                for(int i=0; i<f.size(); i++){
//                    Log.d("Fragment Get", "Fragment: " + Integer.toString(i) + " "
//                            + f.get(i).getClass().getName());
//                }
//
//                Log.d("Fragment Pos", "Position: " + Integer.toString(position));
//
//                switch (position) {
//                    case 0 :
//                        Log.d("Fragment Ret", "Returning new OnboardingFragment1\n");
//                        return new OnboardingFragment1();
//                    case 1 :
//                        Log.d("Fragment Ret", "Returning new OnboardingFragment2\n");
//                        return new OnboardingFragment2();
//                    case 2 :
//                        Log.d("Fragment Ret", "Returning new OnboardingFragment3\n");
//                        return new OnboardingFragment3();
//                    default: return null;
//                }
//
//            }
//
//
//            @Override
//            public int getCount() {
//                return 3;
//            }
//
//            @Override
//            public Parcelable saveState(){
//                return null;
//            }
//        };
//
//        pager.setAdapter(adapter);
//
//        indicatior.setViewPager(pager);
//
//        indicatior.setOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener(){
//            @Override
//            public void onPageSelected(int position) {
//                if(position == 2){
//                    skip.setVisibility(View.GONE);
//                    next.setText("Done");
//                } else {
//                    skip.setVisibility(View.VISIBLE);
//                    next.setText("Next");
//                }
//            }
//        });
//
//        skip.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finishOnboarding();
//            }
//        });
//
//        next.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if(pager.getCurrentItem() == 2){
//                    finishOnboarding();
//                } else {
//                    pager.setCurrentItem(pager.getCurrentItem() + 1, true);
//                }
//            }
//        });
//
//    }
//
//    private void finishOnboarding() {
//
//        SharedPreferences preferences =
//                getSharedPreferences(Util.APP_NAME, MODE_PRIVATE);
//
//        preferences.edit()
//                .putBoolean("onboarding_complete",true).apply();
//
//        Intent intent = new Intent(this, MainActivity.class);
//        startActivity(intent);
//        finish();
//    }
//    }
//}
//
